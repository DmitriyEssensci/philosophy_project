--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.2 (Debian 17.2-1.pgdg120+1)
-- Dumped by pg_dump version 17.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: data_objects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.data_objects (
    id integer NOT NULL,
    person_name character varying NOT NULL,
    period_life character varying NOT NULL,
    years_life character varying NOT NULL,
    school_teaching character varying NOT NULL,
    person_teacher character varying NOT NULL,
    person_followers character varying NOT NULL,
    person_works character varying NOT NULL,
    short_description character varying NOT NULL,
    full_description character varying NOT NULL,
    create_data timestamp without time zone NOT NULL,
    update_data timestamp without time zone NOT NULL
);


ALTER TABLE public.data_objects OWNER TO postgres;

--
-- Name: data_objects_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.data_objects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.data_objects_id_seq OWNER TO postgres;

--
-- Name: data_objects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.data_objects_id_seq OWNED BY public.data_objects.id;


--
-- Name: data_objects id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.data_objects ALTER COLUMN id SET DEFAULT nextval('public.data_objects_id_seq'::regclass);


--
-- Data for Name: data_objects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.data_objects (id, person_name, period_life, years_life, school_teaching, person_teacher, person_followers, person_works, short_description, full_description, create_data, update_data) FROM stdin;
\.
COPY public.data_objects (id, person_name, period_life, years_life, school_teaching, person_teacher, person_followers, person_works, short_description, full_description, create_data, update_data) FROM '$$PATH$$/3360.dat';

--
-- Name: data_objects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.data_objects_id_seq', 17, true);


--
-- Name: data_objects data_objects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.data_objects
    ADD CONSTRAINT data_objects_pkey PRIMARY KEY (id);


--
-- Name: ix_data_objects_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_data_objects_id ON public.data_objects USING btree (id);


--
-- PostgreSQL database dump complete
--

